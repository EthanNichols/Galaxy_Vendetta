I had to package the game like this, please ignore all the 'dll' files, and just run the game by clicking "The Ancient Puzzle.exe"

Again, thank you for playing, and I hope you enjoy it